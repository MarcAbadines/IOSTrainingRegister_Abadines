//
//  HomeViewController.h
//  Signup
//
//  Created by OPSolutions on 25/10/2019.
//  Copyright © 2019 OPSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "SignUpViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewController : UIViewController
@property (assign) NSString *displayString;
@property (strong, readwrite) SignUpViewController *signup;
@property (strong, readwrite) ViewController *login;
@end

NS_ASSUME_NONNULL_END
