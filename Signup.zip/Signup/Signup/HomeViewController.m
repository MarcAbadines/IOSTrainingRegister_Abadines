//
//  HomeViewController.m
//  Signup
//
//  Created by OPSolutions on 25/10/2019.
//  Copyright © 2019 OPSolutions. All rights reserved.
//

#import "HomeViewController.h"
#import "User.h"

@interface HomeViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblWelcome;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [_lblWelcome setText:_displayString];
}


@end
