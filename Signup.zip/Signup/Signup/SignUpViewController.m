//
//  SignUpViewController.m
//  Signup
//
//  Created by OPSolutions on 25/10/2019.
//  Copyright © 2019 OPSolutions. All rights reserved.
//

#import "SignUpViewController.h"
#import "HomeViewController.h"
#import "User.h"

@interface SignUpViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtPhoneNum;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPass;
@property (weak, nonatomic) IBOutlet UITextField *txtConfirmPass;
@property (weak, nonatomic) IBOutlet UIButton *btnRegister;
@property (assign) NSUserDefaults *defaults;

@end

@implementation SignUpViewController
- (IBAction)btnRegisterTapped:(id)sender {
    [self storeDefaults];
    _txtEmail.text = nil;
    _txtPhoneNum.text = nil;
    _txtName.text = nil;
    _txtPass.text = nil;
    _txtConfirmPass.text = nil;
}

- (void)viewDidLoad {
    _defaults = [NSUserDefaults standardUserDefaults];
    [super viewDidLoad];

}

- (void)displayHomeScreen:(NSMutableArray *) userArray{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeViewController *homeViewController = [mainStoryBoard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    NSString *tempString = [NSString stringWithFormat:@"Welcome %@!", ((User *)userArray.lastObject).name];
    homeViewController.displayString = tempString;
    homeViewController.signup = self;
    
    [self presentViewController:homeViewController animated:YES completion:nil];
}

- (void)storeDefaults {
    NSString *email = _txtEmail.text;
    NSString *password = _txtPass.text;
    NSString *fullname = _txtName.text;
    NSString *phone = _txtPhoneNum.text;
    NSString *confirmPass = _txtConfirmPass.text;
    User *user = [[User alloc] initWithEmail:email];
    user.password = password;
    user.name = fullname;
    user.phoneNum = phone;
    bool isExisting = false;
    NSMutableArray *userArray = [[NSMutableArray alloc] initWithArray:[self decodeUserArrayData]];
    for (User *userIterator in userArray) {
        
        
        if ([userIterator.email isEqualToString:email]) {
            isExisting = true;
            break;
        }
    }
    
    if (!isExisting) {
        if ([password isEqualToString:confirmPass]) {
            [userArray addObject:user];
            [self encodeUserArrayData:userArray];
            [self displayHomeScreen:userArray];
        } else {
            [self showAlertWithMessage:@"Password does not match!"];
        }
    } else {
        _txtEmail.text = nil;
        _txtPhoneNum.text = nil;
        _txtName.text = nil;
        _txtPass.text = nil;
        _txtConfirmPass.text = nil;
        [self showAlertWithMessage:@"Email already exist!"];
    }
}

- (void)encodeUserArrayData:(NSMutableArray *)userArray {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userArray requiringSecureCoding:NO error:nil];
    [_defaults setObject:data forKey:@"userArray"];
}

- (NSMutableArray *)decodeUserArrayData {
    NSData *newData = [_defaults objectForKey:@"userArray"];
    NSMutableArray *decodedUserArray = [NSKeyedUnarchiver unarchiveObjectWithData:newData];
    return decodedUserArray;
}

- (void)showAlertWithMessage:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Message:" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Okay" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
