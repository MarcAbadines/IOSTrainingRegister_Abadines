//
//  ViewController.m
//  Signup
//
//  Created by OPSolutions on 24/10/2019.
//  Copyright © 2019 OPSolutions. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"
#import "User.h"
NSString *alert2;
NSString *msg2;
NSString *identifier2;

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPass;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;
@property (weak, nonatomic) IBOutlet UIButton *btnSignUp;

@end

@implementation ViewController

- (IBAction)btnLoginTapped:(UIButton *)sender {
   
    NSString *email = _txtEmail.text;
    NSString *password = _txtPass.text;
    NSMutableArray *usersArray = [self decodeUserArrayData];
    
    for (User *currentUser in usersArray) {
        if ([currentUser.email isEqualToString:email] && [currentUser.password isEqualToString:password]) {
            [self presentThirdScreen:currentUser];
        } else if ([email  isEqual: nil]) {
            [self showAlertWithMessage:@"Please input an email."];
        } else{
            [self showAlertWithMessage:@"Incorrect email or password!"];
        }
    }}

- (IBAction)btnSignUpTapped:(UIButton *)sender {
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (NSMutableArray *)decodeUserArrayData {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *newData = [defaults objectForKey:@"userArray"];
    NSMutableArray *decodedUserArray = [NSKeyedUnarchiver unarchiveObjectWithData:newData];
    return decodedUserArray;
}


- (void)presentThirdScreen:(User *) user{
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeViewController *homeViewController = (HomeViewController*)[mainStoryBoard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    NSString *completeMessage = [NSString stringWithFormat:@"Welcome %@!", user.name];
    homeViewController.displayString = completeMessage;
    homeViewController.login = self;
    [self presentViewController:homeViewController animated:YES completion:nil];
}

- (void)showAlertWithMessage:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Message:" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Okay" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"User tapped okay action!~");
    }];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
